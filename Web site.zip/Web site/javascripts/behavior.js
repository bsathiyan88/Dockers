// JavaScript Document

$(document).ready(function() {

  $("nav#global a").click(function(){
    $("nav#global a").removeClass("fpo");
    $(this).addClass("fpo");
    });
  
});